#include <cstdlib>
#include <mpi.h>
#include <iostream>
#include <string>
#include <cmath>
#include <fstream>

void handle(int exitcode) {
    if (exitcode != MPI_SUCCESS) {
        MPI_Abort(MPI_COMM_WORLD, exitcode);
    }
}

int openFile() {
    // ������ ��������� N.dat
    std::ifstream inputFile("N.dat");

    if (!inputFile.is_open()) {
        std::cerr << "Error opening the file!" << std::endl;
        return 1;
    }

    int n = 0.0;
    std::string line;
    while (getline(inputFile, line)) {
        n = std::atoi(line.c_str());
    }
    inputFile.close();
    return n;
}


int main(int argc, char* argv[]) {
    handle(MPI_Init(&argc, &argv));
    int total_amount = -1, rank = -1;

    int exitcode = MPI_Comm_size(MPI_COMM_WORLD, &total_amount);
    handle(exitcode);

    exitcode = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    handle(exitcode);

    if (120 & total_amount != 0) {
        return -1;
    }

    int arr[120] = {-1};
    int from = 120 * ((double)rank / (double)total_amount);
    int to = 120 * ((double)(1 + rank) / (double)total_amount);
    for (int i = from; i < to; ++i) {
        arr[i] = rank;
        std::cout << arr[i] << std::endl;
    }

    int answer[120] = {-2};
    exitcode = MPI_Gather(&arr[(int)(120 * ((double)rank / (double)total_amount))], 120 / total_amount, MPI_INT, &answer[rank],
                          120 / total_amount, MPI_INT, 0, MPI_COMM_WORLD);
    handle(exitcode);

    if (rank == 0) {
        std::ofstream myfile("outfile3.txt");
        if (myfile.is_open()) {
            for (int count = 0; count < 120; count++) {
                myfile << answer[count] << " ";
            }
            myfile.close();
        }
        else std::cout << "Unable to open file";
    }

    handle(MPI_Finalize());
    return 0;
}
